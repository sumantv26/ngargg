#!============================================= Python Program 6 ============================================!#
#============================================ Removing line(s) with 'a'  ===========================================#


filenamein=str(input("Enter input file name(remove .txt),press enter for default : "))
if filenamein=="":
	filein=open("samplefile.txt",'r')
else:
	try:
		filein=open(filenamein+".txt",'r')
	except:
		print("Sorry, file not found, entering default mode.")
		filein=open("samplefile.txt",'r')

filenameout=str(input("Enter file name(remove .txt),press enter for default : "))
if filenameout=="":
	fileout=open("samplefileout.txt",'w')
else:
	try:
		fileout=open(filenameout+".txt",'w')
	except:
		print("Sorry, file not found, entering default mode.")
		fileout=open("samplefileout.txt",'w')

content=filein.readlines()
for line in content:
	if "a" in line:
		continue
	else:
		fileout.write(line)
filein.close()
fileout.close()