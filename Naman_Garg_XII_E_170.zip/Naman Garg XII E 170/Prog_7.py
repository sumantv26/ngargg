#!============================================= Python Program 7 ============================================!#
#================================================= Recurrsion  =============================================#

def factorial(n):
    if n == 1:
        return 1
    else:
        return (n * factorial(n-1))


num = int(input("Enter number to find factorial : "))
print("The factorial of", num, "is", factorial(num))
