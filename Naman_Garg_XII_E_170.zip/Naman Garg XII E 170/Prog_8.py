#!============================================= Python Program 8 ============================================!#
#============================================Search for Roll Number  ===========================================#

import pickle
 
file = open('samplebin.bin', 'rb')
content = pickle.load(file) 
for keys in content: 
    print(keys, '=>\t', content[keys])

roll=int(input("Enter Roll Number : "))
found=False
for keys in content:
    if content[keys]["Roll number"]==str(roll):
        found=True
        print("\nRoll number found !\n")
        print(keys, '=>\t', content[keys])
        break

if not found:
    print("Sorry roll number not found")

file.close()
