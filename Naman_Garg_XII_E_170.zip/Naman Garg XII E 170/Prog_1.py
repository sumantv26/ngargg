#!============================================== Python Program 1 ============================================!#
#============================================== Programme Assistant ==========================================#

import sys
import time
import importlib

print("Hi There !!! ")
time.sleep(1)
print("I am your personnel assistant and will help you to see the project")
time.sleep(1)
y=str(input("\n\n  Are you Ready ? (Y / N ) : "))
if y.capitalize()=="N":
	print("THANK YOU !!!")
	time.sleep(3)
	exit()

# if sys.version_info[0]==2:
# 	print("You should upgrade to Python 3 or later for better view")
# elif sys.version_info[0]>=3:
# 	print("\033[1;32;40m")

print("\n\n\t\t\t\tWelcome To Python Programmes Made By Naman Garg\n\n")

time.sleep(1)
print("\t Here's List Of Programmes\n")
time.sleep(1)

dict1={1:"Programme Assistant",
2:"Stack And Queue Module",
3:"Stack And Queue",
4:"Rolling Dice And Toss",
5:"Reading file ",
6:"Removing line(s) with 'a'",
7:"Recurssion",
8:"Search for roll number",
9:"Random Password generator",
10:"Counting Characters in file",
11:"Update Marks in Binary File",
12:"File Sorting",
13:"Geometric Design",
14:"Top used phishing keywords",
15:"Hangman",
}
for i in range(1,18):
	print(i," :",dict1[i])

x=True

while x:
	choice=str(input("\n\n\tV -> To View Programmes \n\tE -> Exit \n\t>>> "))
	if choice.capitalize()=="V":
		pgn=int(input("  Please Enter A Programme Number : "))
		pgn="Prog_"+str(pgn)+".py"
		try:
			importlib.import_module(pgn)
		except:
			print("Please enter a VALID INTEGER between 1 and 15")


	elif choice.capitalize()=="E":
		x=False
		print("\n\nTHANK YOU !!!")
		pass

	else:
		print("Enter A Valid Choice")

	time.sleep(2)
