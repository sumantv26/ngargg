#!============================================== Python Program 9 ============================================!#
#============================================= Random Password Generator  ==========================================

import random
import string
length=random.randint(15,25)
psswd=""
use=str(input("Please enter where you will use the Password : "))
for i in range(length):
    char=random.choice(string.ascii_letters + string.digits+"@#$%&")
    psswd+=char
print(psswd)
file=open("password.txt",'a')
file.write("\n"+use+"\t:\t"+psswd)
print("\n\nPassword written successfully to password.txt")
try:
    import clipboard
    clipboard.copy(psswd)
    text = clipboard.paste()
    print("\n\nPassword copied succesfully!")
except:
    print("Please install clipboard to automatically copy password to clipboard")