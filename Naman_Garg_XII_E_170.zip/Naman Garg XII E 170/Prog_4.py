#!=========================================== Python Program 4 ============================================!#
#========================================= Rolling Dice And Toss ==========================================#

import random
import time

def dice(num):
	strr=""
	for x in range(num):
		strr+=str(random.randint(1,6))+" "
	return strr

def toss(num):
	strr=""
	ltoss=["Heads","Tails"]
	for x in range(num):
		strr+=str(ltoss[random.randint(0,1)])+" "
	return strr


x=True

while x:
	choice=str(input("\tR -> Roll dice\n\tT -> Toss\n\tE -> Exit \n\t>>> "))
	if choice.capitalize()=="R":
		inp=int(input("Enter number of times : "))
		print("\nNumber of possible outcomes are\n\t",6**inp)
		for y in dice(inp).split():
			print("   "+str(y))
			time.sleep(1)
	elif choice.capitalize()=="T":
		inp=int(input("Enter number of times : "))
		print("\nNumber of possible outcomes are\n\t",6**inp)
		for y in toss(inp).split():
			print("   "+str(y))
			time.sleep(1)
	elif choice.capitalize()=="E":
		exit()
	else:
		print("Enter A Valid Choice")
