#!============================================= Python Program 12 ============================================!#
#================================================ File Sorting  =============================================#


import os

def makef(folder):
    if os.path.exists(folder):
        pass
    else:
        mkdir(folder)

os.chdir("./")
fol=str(input("\n\nPlease Enter a valid Child Folder(Press Enter for default) : "))
while not os.path.exists(fol):
    if fol=="":
        fol="Sample"
        break
    fol=str(input("\n\nPlease Enter a valid Child Folder(Press Enter for default) : "))

os.chdir(fol)
print("Current Working Directory " , os.getcwd())
for file
