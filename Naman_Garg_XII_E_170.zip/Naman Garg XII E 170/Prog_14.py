#!============================================== Python Program 14 ============================================!#
#============================================ Top used phishing keywords =======================================


occur={}
for i in range(1,11):
    with open("./Phishing EMAILS/Email"+str(i)+".txt","r") as email:
        for word in email.read().split():
            if word.capitalize() in occur:
                occur[word.capitalize()]+=1
            else:
                occur[word]=1

for i in occur.keys():
    if occur[i]>5:
        print(i," Occured ",occur[i],"times")
