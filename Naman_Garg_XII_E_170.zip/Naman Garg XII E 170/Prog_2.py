#!=============================================== Python Program 2 ==============================================!#
#============================================== Stack And Queue Module ============================================#


def stack(list):
	print("List before stack operations : ")
	list.append("newitem")
	print("List after appending : ",list)
	list.pop()
	print("List after stack operations : ",list)

def queue(list):
	print("List before queue operations : ")
	list.append("newitem")
	print("List after appending : ",list)
	list.pop(0)
	print("List after queue operations : ",list)