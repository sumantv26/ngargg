#!============================================== Python Program 10 ============================================!#
#============================================= Counting Characters in File  ==========================================


filename=str(input("Enter file name(remove .txt),press enter for default : "))
if filename=="":
	file=open("samplefile.txt",'r')
else:
	try:
		file=open(filename+".txt",'r')
	except:
		print("Sorry, file not found, entering default mode.")
		file=open("samplefile.txt",'r')

vowel,consonant,upper,lower,char=0,0,0,0,0
for i in file.read():
	char+=1
	if i.isalpha():
		if i.isupper():
			upper+=1
		elif i.islower():
			lower+=1
		if i in ("aeiou"):
			vowel+=1
		elif i not in ("aeiou"):
			consonant+=1
	

print("Vowels in fle are : ",vowel)
print("Consonants in fle are : ",consonant)
print("Uppercase letters in fle are : ",upper)
print("Lowercase letters in fle are : ",lower)
print("Total characters in fle are : ",char)

file.close()