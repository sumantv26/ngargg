#!=========================================== Python Program 5 ============================================!#
#============================================= Reading file  =============================================#

filename=str(input("Enter file name(remove .txt),press enter for default : "))
if filename=="":
	file=open("samplefile.txt",'r')
else:
	try:
		file=open(filename+".txt",'r')
	except:
		print("Sorry, file not found, entering default mode.")
		file=open("samplefile.txt",'r')

content=file.read()
for word in content:
	if word==" ":
		continue
	else:
		print(word,end="#")

file.close()